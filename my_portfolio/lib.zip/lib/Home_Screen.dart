import 'dart:io';
import 'dart:ui';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:url_launcher/url_launcher.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    _floatingController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);
  }

  late AnimationController _floatingController;

  File? _mobileCoverImage;
  Uint8List? _webCoverImage;
  File? _mobileImage;
  Uint8List? _webImage;

  // Profile Data
  String _name = "Kunal Sonawane";
  String _headline = "Flutter Developer | Java | Spring Boot Developer";
  String _location = "Pune, Maharashtra, India";
  String _about =
      "Passionate developer with hands-on experience in Flutter, Java, Spring Boot, and MySQL. I love building real-world applications with clean UI and scalable backend architecture. Always eager to learn new technologies and contribute to innovative projects.";

  final List<Map<String, String>> _experiences = [
    {
      "title": "Flutter Intern",
      "company": "Incubators",
      "duration": "Aug 2024 - Oct 2024 • 3 mos",
      "location": "Pune, Maharashtra, India",
      "description":
          "Worked on real Flutter applications, developing cross-platform mobile solutions and collaborating with the development team on various projects.",
    },
  ];

  final List<Map<String, String>> _education = [
    {
      "school": "Fergusson College, Pune",
      "degree": "Master of Computer Applications - MCA",
      "years": "2023 - 2025",
    },
    {
      "school": "KTHM College, Nashik",
      "degree": "Bachelor of Science - B.Sc Computer Science",
      "years": "2020 - 2023",
    },
  ];

  final List<Map<String, String>> _skills = [
    {"name": "Flutter", "category": "Mobile Development"},
    {"name": "Dart", "category": "Programming Language"},
    {"name": "Java", "category": "Programming Language"},
    {"name": "Spring Boot", "category": "Backend Framework"},
    {"name": "MySQL", "category": "Database Management"},
    {"name": "REST APIs", "category": "Web Services"},
    {"name": "Firebase", "category": "Backend as a Service"},
    {"name": "GitHub", "category": "Version Control"},
  ];

  final List<Map<String, String>> _projects = [
    {
      "title": "Flex Play – Turf Booking App",
      "description":
          "A comprehensive turf booking application built with Flutter and Firebase, featuring real-time availability, secure payments, and user-friendly interface.",
      "tech": "Flutter • Firebase • REST APIs",
      "url": "https://github.com/",
    },
    {
      "title": "Music Player App",
      "description":
          "Feature-rich music player application with playlist management, audio visualization, and cloud integration using Flutter and Firebase.",
      "tech": "Flutter • Firebase • Audio APIs",
      "url": "https://github.com/",
    },
  ];

  final List<Map<String, String>> _certifications = [
    {
      "title": "Flutter Certification",
      "issuer": "Incubators",
      "date": "Issued Oct 2024",
    },
    {
      "title": "Super X Program",
      "issuer": "Professional Development",
      "date": "Issued 2024",
    },
  ];

  Future<void> _pickCoverImage() async {
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    if (image == null) return;

    if (kIsWeb) {
      final bytes = await image.readAsBytes();
      setState(() => _webCoverImage = bytes);
    } else {
      setState(() => _mobileCoverImage = File(image.path));
    }
  }

  Future<void> _pickImage() async {
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    if (image == null) return;

    if (kIsWeb) {
      final bytes = await image.readAsBytes();
      setState(() => _webImage = bytes);
    } else {
      setState(() => _mobileImage = File(image.path));
    }
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final isMobile = size.width < 700;

    return Scaffold(
      backgroundColor: Colors.black,
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          // gradient: LinearGradient(
          //   begin: Alignment.topLeft,
          //   end: Alignment.bottomRight,
          //   colors: [Color(0xFF0F172A), Color(0xFF1E293B), Color(0xFF334155)],
          // ),
        ),
        child: Stack(
          children: [
            /// 🔹 Animated Background Particles (FROM HOME SCREEN)
            ...List.generate(20, (index) {
              return Positioned(
                left: (index * 100) % size.width,
                top: (index * 80) % size.height,
                child: Transform.translate(
                  offset: Offset(
                    0,
                    30 * _floatingController.value * (index % 2 == 0 ? 1 : -1),
                  ),
                  child: Container(
                    width: 4,
                    height: 4,
                    // decoration: BoxDecoration(
                    //   shape: BoxShape.circle,
                    //   color: Colors.white.withOpacity(0.1),
                    //),
                  ),
                ),
              );
            }),

            /// 🔹 EXISTING PROFILE CONTENT (UNCHANGED)
            SafeArea(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  _profileCard(context, isMobile),
                  const SizedBox(height: 8),
                  _aboutCard(),
                  const SizedBox(height: 8),
                  _activityCard(),
                  const SizedBox(height: 8),
                  _experienceCard(),
                  const SizedBox(height: 8),
                  _educationCard(),
                  const SizedBox(height: 8),
                  _skillsCard(),
                  const SizedBox(height: 8),
                  _projectsCard(),
                  const SizedBox(height: 8),
                  _certificationsCard(),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), duration: const Duration(seconds: 1)),
    );
  }

  Widget glassCard({required Widget child}) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Color.fromARGB(255, 93, 3, 97),
            Color.fromARGB(255, 41, 1, 79),
          ],
        ),
      ),

      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
          child: child,
        ),
      ),
    );
  }

  // ================= PROFILE CARD =================
  Widget _profileCard(BuildContext context, bool isMobile) {
    return glassCard(
      child: Column(
        children: [
          Stack(
            clipBehavior: Clip.none,
            children: [
              GestureDetector(
                onTap: _pickImage,
                child: Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFF3B82F6).withOpacity(0.6),
                        blurRadius: 30,
                        spreadRadius: 6,
                      ),
                    ],
                  ),
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: const Color.fromARGB(255, 4, 5, 5),
                        width: 3,
                      ),
                    ),
                    child: CircleAvatar(
                      radius: isMobile ? 48 : 62,
                      backgroundColor: const Color.fromARGB(255, 240, 241, 244),
                      backgroundImage: _getProfileImage(),
                      child:
                          (_mobileImage == null && _webImage == null)
                              ? Icon(
                                Icons.person,
                                size: isMobile ? 50 : 64,
                                color: Colors.white.withOpacity(0.5),
                              )
                              : null,
                    ),
                  ),
                ),
              ).animate().fade().scale(),
            ],
          ),
          Padding(
            padding: EdgeInsets.only(
              left: isMobile ? 20 : 24,
              right: isMobile ? 20 : 24,
              top: 60,
              bottom: 20,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  _name,
                                  style: GoogleFonts.poppins(
                                    fontSize: isMobile ? 24 : 32,
                                    fontWeight: FontWeight.w600,
                                    height: 1.2,
                                  ),
                                ),
                              ),
                              IconButton(
                                icon: Icon(
                                  Icons.edit,
                                  size: 20,
                                  color: const Color.fromARGB(
                                    255,
                                    162,
                                    151,
                                    151,
                                  ),
                                ),
                                onPressed: () => _editProfileInfo(),
                              ),
                            ],
                          ),
                          const SizedBox(height: 4),
                          Text(
                            _headline,
                            style: GoogleFonts.poppins(
                              fontSize: isMobile ? 16 : 18,
                              color: const Color.fromARGB(221, 211, 209, 209),
                              height: 1.4,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Text(
                      _location,
                      style: TextStyle(
                        color: const Color.fromARGB(255, 8, 8, 8),
                        fontSize: 14,
                      ),
                    ),
                    const SizedBox(width: 4),
                    InkWell(
                      onTap: () => _showContactInfo(),
                      child: Text(
                        "• Contact info",
                        style: TextStyle(
                          color: const Color.fromARGB(255, 0, 0, 0),
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  "500+ connections",
                  style: TextStyle(
                    color: const Color.fromARGB(255, 230, 233, 236),
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () => _showSnackBar("Open to work"),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color.fromARGB(
                            255,
                            233,
                            234,
                            235,
                          ),
                          foregroundColor: const Color.fromARGB(255, 10, 8, 8),
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(24),
                          ),
                        ),
                        child: const Text(
                          "Open to work",
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => _showAddSectionDialog(),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: const Color.fromARGB(
                            255,
                            238,
                            235,
                            235,
                          ),

                          padding: const EdgeInsets.symmetric(vertical: 12),
                          side: BorderSide(
                            color: Colors.blue.shade700,
                            width: 1.5,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(24),
                          ),
                        ),
                        child: const Text(
                          "Add section",
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    OutlinedButton(
                      onPressed: () => _showMoreOptions(),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: const Color.fromARGB(
                          255,
                          226,
                          223,
                          223,
                        ),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 12,
                        ),
                        side: BorderSide(color: Colors.blue.shade700),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(24),
                        ),
                      ),
                      child: const Text(
                        "More",
                        style: TextStyle(fontWeight: FontWeight.w600),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ================= ABOUT CARD =================
  Widget _aboutCard() {
    return Container(
      child: Padding(
        padding: const EdgeInsets.all(20),

        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "About",
                  style: GoogleFonts.poppins(
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.edit, size: 20),
                  onPressed: () => _editAbout(),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              _about,
              style: GoogleFonts.poppins(
                fontSize: 14,
                color: const Color.fromARGB(221, 240, 240, 240),
                height: 1.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ================= ACTIVITY CARD =================
  Widget _activityCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Activity",
            style: GoogleFonts.poppins(
              fontSize: 20,
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            "500+ followers",
            style: TextStyle(fontSize: 14, color: Colors.blue.shade700),
          ),
          const SizedBox(height: 16),
          Text(
            "You haven't posted yet",
            style: TextStyle(
              fontSize: 14,
              color: const Color.fromARGB(255, 233, 231, 231),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            "Posts you share will be displayed here",
            style: TextStyle(fontSize: 13, color: Colors.grey.shade500),
          ),
          const SizedBox(height: 16),
          OutlinedButton(
            onPressed: () => _showSnackBar("Show all activity"),
            style: OutlinedButton.styleFrom(
              foregroundColor: Colors.blue.shade700,
              side: BorderSide(color: Colors.blue.shade700, width: 1.5),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(24),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
            ),
            child: const Text(
              "Show all activity",
              style: TextStyle(fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }

  // ================= EXPERIENCE CARD =================
  Widget _experienceCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Experience",
                style: GoogleFonts.poppins(
                  fontSize: 20,
                  fontWeight: FontWeight.w600,
                ),
              ),
              IconButton(
                icon: const Icon(Icons.add, size: 24),
                onPressed: () => _addExperience(),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ..._experiences.map(
            (exp) => _experienceItem(
              exp["title"]!,
              exp["company"]!,
              exp["duration"]!,
              exp["location"]!,
              exp["description"]!,
              onEdit: () => _editExperience(_experiences.indexOf(exp)),
              onDelete: () => _deleteExperience(_experiences.indexOf(exp)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _experienceItem(
    String title,
    String company,
    String duration,
    String location,
    String description, {
    VoidCallback? onEdit,
    VoidCallback? onDelete,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: Colors.grey.shade200,
              borderRadius: BorderRadius.circular(4),
            ),
            child: const Icon(Icons.business, color: Colors.grey),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        title,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    PopupMenuButton(
                      icon: Icon(Icons.more_vert, size: 20),
                      itemBuilder:
                          (context) => [
                            PopupMenuItem(
                              child: const Text("Edit"),
                              onTap: onEdit,
                            ),
                            PopupMenuItem(
                              child: const Text("Delete"),
                              onTap: onDelete,
                            ),
                          ],
                    ),
                  ],
                ),
                const SizedBox(height: 2),
                Text(
                  company,
                  style: TextStyle(fontSize: 14, color: Colors.grey.shade800),
                ),
                const SizedBox(height: 2),
                Text(
                  duration,
                  style: TextStyle(fontSize: 13, color: Colors.grey.shade600),
                ),
                const SizedBox(height: 2),
                Text(
                  location,
                  style: TextStyle(fontSize: 13, color: Colors.grey.shade600),
                ),
                const SizedBox(height: 8),
                Text(
                  description,
                  style: TextStyle(
                    fontSize: 14,
                    color: const Color.fromARGB(221, 240, 240, 240),
                    height: 1.4,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ================= EDUCATION CARD =================
  Widget _educationCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Education",
                style: GoogleFonts.poppins(
                  fontSize: 20,
                  fontWeight: FontWeight.w600,
                ),
              ),
              IconButton(
                icon: const Icon(Icons.add, size: 24),
                onPressed: () => _addEducation(),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ..._education.map(
            (edu) => _educationItem(
              edu["school"]!,
              edu["degree"]!,
              edu["years"]!,
              onEdit: () => _editEducation(_education.indexOf(edu)),
              onDelete: () => _deleteEducation(_education.indexOf(edu)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _educationItem(
    String school,
    String degree,
    String years, {
    VoidCallback? onEdit,
    VoidCallback? onDelete,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: Colors.grey.shade200,
              borderRadius: BorderRadius.circular(4),
            ),
            child: const Icon(Icons.school, color: Colors.grey),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        school,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    PopupMenuButton(
                      icon: Icon(Icons.more_vert, size: 20),
                      itemBuilder:
                          (context) => [
                            PopupMenuItem(
                              child: const Text("Edit"),
                              onTap: onEdit,
                            ),
                            PopupMenuItem(
                              child: const Text("Delete"),
                              onTap: onDelete,
                            ),
                          ],
                    ),
                  ],
                ),
                const SizedBox(height: 2),
                Text(
                  degree,
                  style: TextStyle(
                    fontSize: 14,
                    color: const Color.fromARGB(221, 240, 240, 240),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  years,
                  style: TextStyle(
                    fontSize: 13,
                    color: const Color.fromARGB(221, 240, 240, 240),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ================= SKILLS CARD =================
  Widget _skillsCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Skills",
                style: GoogleFonts.poppins(
                  fontSize: 20,
                  fontWeight: FontWeight.w600,
                ),
              ),
              IconButton(
                icon: const Icon(Icons.add, size: 24),
                onPressed: () => _addSkill(),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ..._skills.map(
            (skill) => _skillItem(
              skill["name"]!,
              skill["category"]!,
              onDelete: () => _deleteSkill(_skills.indexOf(skill)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _skillItem(String skill, String category, {VoidCallback? onDelete}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      skill,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      category,
                      style: TextStyle(
                        fontSize: 13,
                        color: Colors.grey.shade600,
                      ),
                    ),
                  ],
                ),
              ),
              IconButton(
                icon: Icon(Icons.close, size: 18, color: Colors.grey.shade600),
                onPressed: onDelete,
              ),
            ],
          ),
          const SizedBox(height: 8),
          Divider(color: Colors.grey.shade300, height: 1),
        ],
      ),
    );
  }

  // ================= PROJECTS CARD =================
  Widget _projectsCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Projects",
                style: GoogleFonts.poppins(
                  fontSize: 20,
                  fontWeight: FontWeight.w600,
                ),
              ),
              IconButton(
                icon: const Icon(Icons.add, size: 24),
                onPressed: () => _addProject(),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ..._projects.map(
            (project) => _projectItem(
              project["title"]!,
              project["description"]!,
              project["tech"]!,
              project["url"]!,
              onEdit: () => _editProject(_projects.indexOf(project)),
              onDelete: () => _deleteProject(_projects.indexOf(project)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _projectItem(
    String title,
    String description,
    String tech,
    String url, {
    VoidCallback? onEdit,
    VoidCallback? onDelete,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: Colors.grey.shade200,
                  borderRadius: BorderRadius.circular(4),
                ),
                child: const Icon(
                  Icons.code,
                  color: const Color.fromARGB(221, 240, 240, 240),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            title,
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                        PopupMenuButton(
                          icon: Icon(Icons.more_vert, size: 20),
                          itemBuilder:
                              (context) => [
                                PopupMenuItem(
                                  child: const Text("Edit"),
                                  onTap: onEdit,
                                ),
                                PopupMenuItem(
                                  child: const Text("Delete"),
                                  onTap: onDelete,
                                ),
                              ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      description,
                      style: TextStyle(
                        fontSize: 14,
                        color: const Color.fromARGB(221, 240, 240, 240),
                        height: 1.4,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      tech,
                      style: TextStyle(
                        fontSize: 13,
                        color: Colors.grey.shade600,
                      ),
                    ),
                    const SizedBox(height: 8),
                    InkWell(
                      onTap: () => launchUrl(Uri.parse(url)),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.link,
                            size: 16,
                            color: Colors.blue.shade700,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            "View Project",
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.blue.shade700,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Divider(color: Colors.grey.shade300, height: 1),
          const SizedBox(height: 12),
        ],
      ),
    );
  }

  // ================= CERTIFICATIONS CARD =================
  Widget _certificationsCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Licenses & Certifications",
                style: GoogleFonts.poppins(
                  fontSize: 19,
                  fontWeight: FontWeight.w600,
                ),
              ),

              IconButton(
                icon: const Icon(Icons.add, size: 24),
                onPressed: () => _addCertification(),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ..._certifications.map(
            (cert) => _certificationItem(
              cert["title"]!,
              cert["issuer"]!,
              cert["date"]!,
              onEdit: () => _editCertification(_certifications.indexOf(cert)),
              onDelete:
                  () => _deleteCertification(_certifications.indexOf(cert)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _certificationItem(
    String title,
    String issuer,
    String date, {
    VoidCallback? onEdit,
    VoidCallback? onDelete,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: Colors.grey.shade200,
              borderRadius: BorderRadius.circular(4),
            ),
            child: const Icon(Icons.workspace_premium, color: Colors.grey),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        title,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                    PopupMenuButton(
                      icon: Icon(Icons.more_vert, size: 20),
                      itemBuilder:
                          (context) => [
                            PopupMenuItem(
                              child: const Text("Edit"),
                              onTap: onEdit,
                            ),
                            PopupMenuItem(
                              child: const Text("Delete"),
                              onTap: onDelete,
                            ),
                          ],
                    ),
                  ],
                ),
                const SizedBox(height: 2),
                Text(
                  issuer,
                  style: TextStyle(fontSize: 14, color: Colors.grey.shade800),
                ),
                const SizedBox(height: 2),
                Text(
                  date,
                  style: TextStyle(fontSize: 13, color: Colors.grey.shade600),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ================= EDIT DIALOGS =================
  void _editProfileInfo() {
    final nameController = TextEditingController(text: _name);
    final headlineController = TextEditingController(text: _headline);
    final locationController = TextEditingController(text: _location);

    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text("Edit Profile"),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: nameController,
                    decoration: const InputDecoration(
                      labelText: "Name",
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: headlineController,
                    decoration: const InputDecoration(
                      labelText: "Headline",
                      border: OutlineInputBorder(),
                    ),
                    maxLines: 2,
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: locationController,
                    decoration: const InputDecoration(
                      labelText: "Location",
                      border: OutlineInputBorder(),
                    ),
                  ),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text("Cancel"),
              ),
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    _name = nameController.text;
                    _headline = headlineController.text;
                    _location = locationController.text;
                  });
                  Navigator.pop(context);
                },
                child: const Text("Save"),
              ),
            ],
          ),
    );
  }

  void _editAbout() {
    final controller = TextEditingController(text: _about);

    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text("Edit About"),
            content: TextField(
              controller: controller,
              decoration: const InputDecoration(
                labelText: "About",
                border: OutlineInputBorder(),
              ),
              maxLines: 6,
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text("Cancel"),
              ),
              ElevatedButton(
                onPressed: () {
                  setState(() => _about = controller.text);
                  Navigator.pop(context);
                },
                child: const Text("Save"),
              ),
            ],
          ),
    );
  }

  void _addExperience() {
    final titleController = TextEditingController();
    final companyController = TextEditingController();
    final durationController = TextEditingController();
    final locationController = TextEditingController();
    final descriptionController = TextEditingController();

    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text("Add Experience"),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: titleController,
                    decoration: const InputDecoration(
                      labelText: "Title",
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: companyController,
                    decoration: const InputDecoration(
                      labelText: "Company",
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: durationController,
                    decoration: const InputDecoration(
                      labelText: "Duration (e.g., Jan 2024 - Present)",
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: locationController,
                    decoration: const InputDecoration(
                      labelText: "Location",
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: descriptionController,
                    decoration: const InputDecoration(
                      labelText: "Description",
                      border: OutlineInputBorder(),
                    ),
                    maxLines: 4,
                  ),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text("Cancel"),
              ),
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    _experiences.add({
                      "title": titleController.text,
                      "company": companyController.text,
                      "duration": durationController.text,
                      "location": locationController.text,
                      "description": descriptionController.text,
                    });
                  });
                  Navigator.pop(context);
                },
                child: const Text("Add"),
              ),
            ],
          ),
    );
  }

  void _editExperience(int index) {
    final exp = _experiences[index];
    final titleController = TextEditingController(text: exp["title"]);
    final companyController = TextEditingController(text: exp["company"]);
    final durationController = TextEditingController(text: exp["duration"]);
    final locationController = TextEditingController(text: exp["location"]);
    final descriptionController = TextEditingController(
      text: exp["description"],
    );

    Future.delayed(Duration.zero, () {
      showDialog(
        context: context,
        builder:
            (context) => AlertDialog(
              title: const Text("Edit Experience"),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: titleController,
                      decoration: const InputDecoration(
                        labelText: "Title",
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: companyController,
                      decoration: const InputDecoration(
                        labelText: "Company",
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: durationController,
                      decoration: const InputDecoration(
                        labelText: "Duration",
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: locationController,
                      decoration: const InputDecoration(
                        labelText: "Location",
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: descriptionController,
                      decoration: const InputDecoration(
                        labelText: "Description",
                        border: OutlineInputBorder(),
                      ),
                      maxLines: 4,
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text("Cancel"),
                ),
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      _experiences[index] = {
                        "title": titleController.text,
                        "company": companyController.text,
                        "duration": durationController.text,
                        "location": locationController.text,
                        "description": descriptionController.text,
                      };
                    });
                    Navigator.pop(context);
                  },
                  child: const Text("Save"),
                ),
              ],
            ),
      );
    });
  }

  void _deleteExperience(int index) {
    setState(() => _experiences.removeAt(index));
  }

  void _addEducation() {
    final schoolController = TextEditingController();
    final degreeController = TextEditingController();
    final yearsController = TextEditingController();

    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text("Add Education"),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: schoolController,
                  decoration: const InputDecoration(
                    labelText: "School",
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: degreeController,
                  decoration: const InputDecoration(
                    labelText: "Degree",
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: yearsController,
                  decoration: const InputDecoration(
                    labelText: "Years (e.g., 2020 - 2024)",
                    border: OutlineInputBorder(),
                  ),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text("Cancel"),
              ),
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    _education.add({
                      "school": schoolController.text,
                      "degree": degreeController.text,
                      "years": yearsController.text,
                    });
                  });
                  Navigator.pop(context);
                },
                child: const Text("Add"),
              ),
            ],
          ),
    );
  }

  void _editEducation(int index) {
    final edu = _education[index];
    final schoolController = TextEditingController(text: edu["school"]);
    final degreeController = TextEditingController(text: edu["degree"]);
    final yearsController = TextEditingController(text: edu["years"]);

    Future.delayed(Duration.zero, () {
      showDialog(
        context: context,
        builder:
            (context) => AlertDialog(
              title: const Text("Edit Education"),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: schoolController,
                    decoration: const InputDecoration(
                      labelText: "School",
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: degreeController,
                    decoration: const InputDecoration(
                      labelText: "Degree",
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: yearsController,
                    decoration: const InputDecoration(
                      labelText: "Years",
                      border: OutlineInputBorder(),
                    ),
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text("Cancel"),
                ),
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      _education[index] = {
                        "school": schoolController.text,
                        "degree": degreeController.text,
                        "years": yearsController.text,
                      };
                    });
                    Navigator.pop(context);
                  },
                  child: const Text("Save"),
                ),
              ],
            ),
      );
    });
  }

  void _deleteEducation(int index) {
    setState(() => _education.removeAt(index));
  }

  void _addSkill() {
    final nameController = TextEditingController();
    final categoryController = TextEditingController();

    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text("Add Skill"),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: nameController,
                  decoration: const InputDecoration(
                    labelText: "Skill Name",
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: categoryController,
                  decoration: const InputDecoration(
                    labelText: "Category",
                    border: OutlineInputBorder(),
                  ),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text("Cancel"),
              ),
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    _skills.add({
                      "name": nameController.text,
                      "category": categoryController.text,
                    });
                  });
                  Navigator.pop(context);
                },
                child: const Text("Add"),
              ),
            ],
          ),
    );
  }

  void _deleteSkill(int index) {
    setState(() => _skills.removeAt(index));
  }

  void _addProject() {
    final titleController = TextEditingController();
    final descriptionController = TextEditingController();
    final techController = TextEditingController();
    final urlController = TextEditingController();

    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text("Add Project"),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: titleController,
                    decoration: const InputDecoration(
                      labelText: "Project Title",
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: descriptionController,
                    decoration: const InputDecoration(
                      labelText: "Description",
                      border: OutlineInputBorder(),
                    ),
                    maxLines: 3,
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: techController,
                    decoration: const InputDecoration(
                      labelText: "Technologies (e.g., Flutter • Firebase)",
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: urlController,
                    decoration: const InputDecoration(
                      labelText: "Project URL",
                      border: OutlineInputBorder(),
                    ),
                  ),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text("Cancel"),
              ),
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    _projects.add({
                      "title": titleController.text,
                      "description": descriptionController.text,
                      "tech": techController.text,
                      "url": urlController.text,
                    });
                  });
                  Navigator.pop(context);
                },
                child: const Text("Add"),
              ),
            ],
          ),
    );
  }

  void _editProject(int index) {
    final project = _projects[index];
    final titleController = TextEditingController(text: project["title"]);
    final descriptionController = TextEditingController(
      text: project["description"],
    );
    final techController = TextEditingController(text: project["tech"]);
    final urlController = TextEditingController(text: project["url"]);

    Future.delayed(Duration.zero, () {
      showDialog(
        context: context,
        builder:
            (context) => AlertDialog(
              title: const Text("Edit Project"),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: titleController,
                      decoration: const InputDecoration(
                        labelText: "Project Title",
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: descriptionController,
                      decoration: const InputDecoration(
                        labelText: "Description",
                        border: OutlineInputBorder(),
                      ),
                      maxLines: 3,
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: techController,
                      decoration: const InputDecoration(
                        labelText: "Technologies",
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: urlController,
                      decoration: const InputDecoration(
                        labelText: "Project URL",
                        border: OutlineInputBorder(),
                      ),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text("Cancel"),
                ),
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      _projects[index] = {
                        "title": titleController.text,
                        "description": descriptionController.text,
                        "tech": techController.text,
                        "url": urlController.text,
                      };
                    });
                    Navigator.pop(context);
                  },
                  child: const Text("Save"),
                ),
              ],
            ),
      );
    });
  }

  void _deleteProject(int index) {
    setState(() => _projects.removeAt(index));
  }

  void _addCertification() {
    final titleController = TextEditingController();
    final issuerController = TextEditingController();
    final dateController = TextEditingController();

    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text("Add Certification"),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: titleController,
                  decoration: const InputDecoration(
                    labelText: "Certification Title",
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: issuerController,
                  decoration: const InputDecoration(
                    labelText: "Issuer",
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: dateController,
                  decoration: const InputDecoration(
                    labelText: "Issue Date (e.g., Issued Jan 2024)",
                    border: OutlineInputBorder(),
                  ),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text("Cancel"),
              ),
              ElevatedButton(
                onPressed: () {
                  setState(() {
                    _certifications.add({
                      "title": titleController.text,
                      "issuer": issuerController.text,
                      "date": dateController.text,
                    });
                  });
                  Navigator.pop(context);
                },
                child: const Text("Add"),
              ),
            ],
          ),
    );
  }

  void _editCertification(int index) {
    final cert = _certifications[index];
    final titleController = TextEditingController(text: cert["title"]);
    final issuerController = TextEditingController(text: cert["issuer"]);
    final dateController = TextEditingController(text: cert["date"]);

    Future.delayed(Duration.zero, () {
      showDialog(
        context: context,
        builder:
            (context) => AlertDialog(
              title: const Text("Edit Certification"),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    controller: titleController,
                    decoration: const InputDecoration(
                      labelText: "Certification Title",
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: issuerController,
                    decoration: const InputDecoration(
                      labelText: "Issuer",
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: dateController,
                    decoration: const InputDecoration(
                      labelText: "Issue Date",
                      border: OutlineInputBorder(),
                    ),
                  ),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text("Cancel"),
                ),
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      _certifications[index] = {
                        "title": titleController.text,
                        "issuer": issuerController.text,
                        "date": dateController.text,
                      };
                    });
                    Navigator.pop(context);
                  },
                  child: const Text("Save"),
                ),
              ],
            ),
      );
    });
  }

  void _deleteCertification(int index) {
    setState(() => _certifications.removeAt(index));
  }

  void _showContactInfo() {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text("Contact Info"),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ListTile(
                  leading: const Icon(Icons.email),
                  title: const Text("Email"),
                  subtitle: const Text("kunalsonawane5802@gmail.com"),
                  onTap:
                      () => launchUrl(
                        Uri.parse("mailto:kunalsonawane5802@gmail.com"),
                      ),
                ),
                ListTile(
                  leading: const Icon(Icons.link),
                  title: const Text("LinkedIn"),
                  subtitle: const Text("linkedin.com/in/yourprofile"),
                  onTap: () => launchUrl(Uri.parse("https://linkedin.com")),
                ),
                ListTile(
                  leading: const Icon(Icons.phone),
                  title: const Text("Phone"),
                  subtitle: const Text("+91 XXXXXXXXXX"),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text("Close"),
              ),
            ],
          ),
    );
  }

  void _showAddSectionDialog() {
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: const Text("Add Section"),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ListTile(
                  leading: const Icon(Icons.language),
                  title: const Text("Languages"),
                  onTap: () {
                    Navigator.pop(context);
                    _showSnackBar("Languages section");
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.volunteer_activism),
                  title: const Text("Volunteer Experience"),
                  onTap: () {
                    Navigator.pop(context);
                    _showSnackBar("Volunteer section");
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.emoji_events),
                  title: const Text("Honors & Awards"),
                  onTap: () {
                    Navigator.pop(context);
                    _showSnackBar("Awards section");
                  },
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text("Cancel"),
              ),
            ],
          ),
    );
  }

  void _showMoreOptions() {
    showModalBottomSheet(
      context: context,
      builder:
          (context) => Container(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ListTile(
                  leading: const Icon(Icons.share),
                  title: const Text("Share profile"),
                  onTap: () {
                    Navigator.pop(context);
                    _showSnackBar("Share profile");
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.qr_code),
                  title: const Text("QR code"),
                  onTap: () {
                    Navigator.pop(context);
                    _showSnackBar("QR code");
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.download),
                  title: const Text("Save as PDF"),
                  onTap: () {
                    Navigator.pop(context);
                    _showSnackBar("Save as PDF");
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.visibility),
                  title: const Text("View in profile mode"),
                  onTap: () {
                    Navigator.pop(context);
                    _showSnackBar("Profile mode");
                  },
                ),
              ],
            ),
          ),
    );
  }

  // ================= HELPER METHODS =================
  DecorationImage? _getCoverImage() {
    if (kIsWeb && _webCoverImage != null) {
      return DecorationImage(
        image: MemoryImage(_webCoverImage!),
        fit: BoxFit.cover,
      );
    } else if (!kIsWeb && _mobileCoverImage != null) {
      return DecorationImage(
        image: FileImage(_mobileCoverImage!),
        fit: BoxFit.cover,
      );
    }
    return null;
  }

  ImageProvider? _getProfileImage() {
    if (kIsWeb && _webImage != null) {
      return MemoryImage(_webImage!);
    } else if (!kIsWeb && _mobileImage != null) {
      return FileImage(_mobileImage!);
    }
    return null;
  }

  @override
  void dispose() {
    _floatingController.dispose();
    super.dispose();
  }
}
