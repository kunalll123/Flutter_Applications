import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dart:ui';
import 'dart:math' as math;
import 'package:url_launcher/url_launcher.dart';

class AboutScreen extends StatefulWidget {
  const AboutScreen({super.key});

  @override
  State<AboutScreen> createState() => _AboutScreenState();
}

class _AboutScreenState extends State<AboutScreen>
    with TickerProviderStateMixin {
  late AnimationController _orbitalController;
  late AnimationController _pulseController;

  @override
  void initState() {
    super.initState();
    _orbitalController = AnimationController(
      duration: const Duration(seconds: 25),
      vsync: this,
    )..repeat();

    _pulseController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _orbitalController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  Future<void> _launchURL(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Could not launch $url')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final isDesktop = size.width > 1024;
    final isTablet = size.width > 600 && size.width <= 1024;
    final isMobile = size.width <= 600;

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: _buildAppBar(isMobile),
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF030712), Color(0xFF0F172A), Color(0xFF1E1B4B)],
          ),
        ),
        child: SingleChildScrollView(
          child: Column(
            children: [
              _buildHeroSection(size, isDesktop, isTablet, isMobile),
              const SizedBox(height: 40),
              _buildProfileSection(isDesktop, isTablet, isMobile),
              const SizedBox(height: 80),
              _buildSkillsSection(isDesktop, isTablet, isMobile),
              const SizedBox(height: 80),
              _buildExperienceSection(isDesktop, isTablet, isMobile),
              const SizedBox(height: 80),
              _buildProjectsSection(isDesktop, isTablet, isMobile),
              const SizedBox(height: 80),
              _buildEducationSection(isDesktop, isTablet, isMobile),
              const SizedBox(height: 100),
              _buildMissionSection(isMobile),
              const SizedBox(height: 100),
              _buildContactSection(isMobile),
              const SizedBox(height: 80),
            ],
          ),
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(bool isMobile) {
    return AppBar(
      elevation: 0,
      backgroundColor: Colors.transparent,
      flexibleSpace: ClipRect(
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
          child: Container(color: Colors.black.withOpacity(0.2)),
        ),
      ),
      leading: IconButton(
        icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white),
        onPressed: () => Navigator.pop(context),
      ),
      title: Text(
        "Portfolio",
        style: GoogleFonts.poppins(
          color: Colors.white,
          fontWeight: FontWeight.bold,
        ),
      ),
      centerTitle: true,
    );
  }

  Widget _buildHeroSection(
    Size size,
    bool isDesktop,
    bool isTablet,
    bool isMobile,
  ) {
    final skills = [
      {'name': 'JAVA', 'color': const Color(0xFF2196F3)},
      {'name': 'FLUTTER', 'color': const Color(0xFF00BCD4)},
      {'name': 'SPRING BOOT', 'color': const Color(0xFF4CAF50)},
      {'name': 'MYSQL', 'color': const Color(0xFFFFA726)},
      {'name': 'FIREBASE', 'color': const Color(0xFFFFCA28)},
      {'name': 'REST API', 'color': const Color(0xFFE53935)},
      {'name': 'DART', 'color': const Color(0xFF3F51B5)},
      {'name': 'CLEAN ARCH', 'color': const Color(0xFF9C27B0)},
    ];

    return SizedBox(
      height: isMobile ? 600 : 800,
      child: Stack(
        alignment: Alignment.center,
        children: [
          ...List.generate(skills.length, (index) {
            final angle = (index * (360 / skills.length)) * math.pi / 180;
            final radius = isMobile ? 160.0 : 300.0;
            return AnimatedBuilder(
              animation: _orbitalController,
              builder: (context, child) {
                final animatedAngle =
                    angle + (_orbitalController.value * 2 * math.pi);
                return Transform.translate(
                  offset: Offset(
                    math.cos(animatedAngle) * radius,
                    math.sin(animatedAngle) * radius,
                  ),
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: (skills[index]['color'] as Color).withOpacity(
                        0.15,
                      ),
                      border: Border.all(
                        color: (skills[index]['color'] as Color).withOpacity(
                          0.5,
                        ),
                      ),
                    ),
                    child: Text(
                      skills[index]['name'] as String,
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: isMobile ? 10 : 12,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                );
              },
            );
          }),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'Kunal Sonawane',
                style: GoogleFonts.poppins(
                  color: Colors.white,
                  fontSize: isMobile ? 36 : 54,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 8,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xFF6366F1),
                  borderRadius: BorderRadius.circular(30),
                ),
                child: Text(
                  'FULL STACK ENGINEER',
                  style: GoogleFonts.orbitron(
                    color: Colors.white,
                    fontSize: 14,
                    letterSpacing: 2,
                  ),
                ),
              ),
              const SizedBox(height: 30),
              AnimatedBuilder(
                animation: _pulseController,
                builder:
                    (context, child) => Transform.scale(
                      scale: 1.0 + (_pulseController.value * 0.05),
                      child: Container(
                        width: isMobile ? 220 : 320,
                        height: isMobile ? 220 : 320,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: const Color(0xFF6366F1),
                            width: 4,
                          ),
                          image: const DecorationImage(
                            image: AssetImage('assets/all assets/profile.jpeg'),
                            fit: BoxFit.cover,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFF6366F1).withOpacity(0.3),
                              blurRadius: 40,
                              spreadRadius: 10,
                            ),
                          ],
                        ),
                      ),
                    ),
              ),
            ],
          ),
        ],
      ),
    ).animate().fadeIn(duration: 1000.ms);
  }

  Widget _buildProfileSection(bool isDesktop, bool isTablet, bool isMobile) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: isMobile ? 30 : 100),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "MY JOURNEY",
            style: GoogleFonts.orbitron(
              color: const Color(0xFF6366F1),
              fontWeight: FontWeight.bold,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 20),
          Text(
            "I am a passionate Full Stack Developer who enjoys turning ideas into scalable applications. My journey began during my MCA with a curiosity for mobile systems, leading me to master Java and backend architecture.\n\nToday, I bridge the gap between elegant UI and robust logic using Flutter, Spring Boot, and MySQL. I believe in a 'Code to the Core' philosophy—designing with intent, implementing clean code, and delivering user-centric solutions.",
            style: GoogleFonts.poppins(
              color: Colors.white70,
              fontSize: 16,
              height: 1.8,
            ),
          ),
        ],
      ),
    ).animate().fadeIn(delay: 400.ms).slideY(begin: 0.1);
  }

  Widget _buildExperienceSection(bool isDesktop, bool isTablet, bool isMobile) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: isMobile ? 20 : 100),
      child: Column(
        children: [
          Text(
            "Professional Experience",
            style: GoogleFonts.poppins(
              color: Colors.white,
              fontSize: 28,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 40),
          _buildExpCard(
            "Flutter Developer Intern",
            "Incubators System | Aug 2024 - Oct 2024",
            [
              "Implemented Secure Authentication & Role-Based Access Control.",
              "Integrated Spring Boot REST APIs with Flutter frontend.",
              "Managed real-time data flow using Firebase & WebSockets.",
              "Built responsive UI supporting both Mobile and Web platforms.",
              "Applied Clean Architecture for better maintainability.",
            ],
            isMobile,
          ),
        ],
      ),
    );
  }

  Widget _buildExpCard(
    String title,
    String subtitle,
    List<String> points,
    bool isMobile,
  ) {
    return Container(
      padding: const EdgeInsets.all(30),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: GoogleFonts.poppins(
              color: const Color(0xFF6366F1),
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          Text(
            subtitle,
            style: GoogleFonts.poppins(color: Colors.white38, fontSize: 14),
          ),
          const Divider(height: 30, color: Colors.white10),
          ...points.map(
            (p) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.bolt, color: Color(0xFF6366F1), size: 18),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      p,
                      style: GoogleFonts.poppins(
                        color: Colors.white70,
                        fontSize: 14,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSkillsSection(bool isDesktop, bool isTablet, bool isMobile) {
    return Column(
      children: [
        Text(
          "Current Tech Stack",
          style: GoogleFonts.poppins(
            color: Colors.white,
            fontSize: 28,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 30),
        Wrap(
          spacing: 15,
          runSpacing: 15,
          alignment: WrapAlignment.center,
          children: [
            _skillChip("Flutter"),
            _skillChip("Spring Boot"),
            _skillChip("Java"),
            _skillChip("MySQL"),
            _skillChip("Firebase"),
            _skillChip("Clean Arch"),
            _skillChip("Microservices", isLearning: true),
            _skillChip("DSA", isLearning: true),
          ],
        ),
      ],
    );
  }

  Widget _skillChip(String label, {bool isLearning = false}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
      decoration: BoxDecoration(
        color:
            isLearning
                ? Colors.transparent
                : const Color(0xFF6366F1).withOpacity(0.1),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(
          color: isLearning ? Colors.white24 : const Color(0xFF6366F1),
        ),
      ),
      child: Text(
        isLearning ? "Learning: $label" : label,
        style: GoogleFonts.poppins(color: Colors.white, fontSize: 14),
      ),
    );
  }

  // Reuse your existing _buildProjectsSection and _buildEducationSection here
  // Ensure the styling matches the new deep-blue theme.

  Widget _buildMissionSection(bool isMobile) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 60),
      width: double.infinity,
      color: Colors.white.withOpacity(0.02),
      child: Column(
        children: [
          Text(
            "KNOW THE CODE, TILL THE CORE.",
            textAlign: TextAlign.center,
            style: GoogleFonts.orbitron(
              color: Colors.white,
              fontSize: isMobile ? 22 : 32,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: 800,
            child: Text(
              "My goal is to build impactful, scalable products that solve real-world problems. I am constantly refining my skills in Microservices and System Design to become a world-class Full Stack Engineer.",
              textAlign: TextAlign.center,
              style: GoogleFonts.poppins(color: Colors.white60, fontSize: 16),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContactSection(bool isMobile) {
    return Column(
      children: [
        Text(
          "Let's Build Something Together",
          style: GoogleFonts.poppins(
            color: Colors.white,
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 30),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            IconButton(
              onPressed: () => _launchURL("https://github.com/kunalll123"),
              icon: const Icon(Icons.code, color: Colors.white),
            ),
            const SizedBox(width: 20),
            IconButton(
              onPressed:
                  () => _launchURL(
                    "https://linkedin.com/in/kunal-sonawane-732ba6224/",
                  ),
              icon: const Icon(Icons.business, color: Colors.white),
            ),
            const SizedBox(width: 20),
            IconButton(
              onPressed: () => _launchURL("mailto:kunalsonawane5802@gmail.com"),
              icon: const Icon(Icons.email, color: Colors.white),
            ),
          ],
        ),
      ],
    );
  }

  // Place holders for your other UI functions (_buildEducationCard, etc)
  Widget _buildEducationSection(bool isD, bool isT, bool isM) => Container();
  Widget _buildProjectsSection(bool isD, bool isT, bool isM) => Container();
}
