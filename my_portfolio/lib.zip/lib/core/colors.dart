import 'package:flutter/material.dart';

class AppColors {
  static const primary = Color(0xFF38BDF8);
  static const card = Color(0xFF1E293B);
  static const text = Colors.white70;
}
