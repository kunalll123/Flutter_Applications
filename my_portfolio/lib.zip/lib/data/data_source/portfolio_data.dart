import 'package:my_portfolio/data/models/project_model.dart';

final projects = [
  Project(
    title: "Flex Play",
    description: "Cricket turf booking app using Flutter & Firebase",
    tech: "Flutter • Firebase",
    github: "https://github.com/kunal/flex-play",
  ),
];
