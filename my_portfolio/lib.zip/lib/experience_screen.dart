import 'package:flutter/material.dart';
import '../utils/responsive.dart';

class ExperienceScreen extends StatelessWidget {
  const ExperienceScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Experience',
          style: TextStyle(fontSize: Responsive.fontSize(context, 20)),
        ),
        backgroundColor: const Color(0xFF1E1E2E),
        elevation: 0,
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF0A0E21), Color(0xFF1E1E2E)],
          ),
        ),
        child: ListView(
          padding: EdgeInsets.all(Responsive.padding(context)),
          children: [
            _buildExperienceCard(
              context,
              'Flutter Developer Intern',
              'Incubators System',
              'August 2024 - October 2024',
              '3 Months',
              [
                'Developed mobile applications using Flutter',
                'Collaborated with team on various projects',
                'Learned best practices in mobile development',
                'Implemented responsive UI designs',
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildExperienceCard(
    BuildContext context,
    String role,
    String company,
    String duration,
    String period,
    List<String> responsibilities,
  ) {
    return Container(
      padding: EdgeInsets.all(Responsive.padding(context)),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.white.withOpacity(0.08),
            Colors.white.withOpacity(0.03),
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header with icon and title
          Row(
            children: [
              Container(
                padding: EdgeInsets.all(Responsive.isMobile(context) ? 12 : 16),
                decoration: BoxDecoration(
                  color: const Color(0xFF2196F3).withOpacity(0.2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  Icons.work,
                  color: const Color(0xFF2196F3),
                  size: Responsive.iconSize(context, 30),
                ),
              ),
              SizedBox(width: Responsive.isMobile(context) ? 12 : 20),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      role,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: Responsive.fontSize(context, 18),
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      company,
                      style: TextStyle(
                        color: const Color(0xFF64B5F6),
                        fontSize: Responsive.fontSize(context, 15),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: Responsive.isMobile(context) ? 12 : 16),

          // Duration and period - Responsive layout
          Responsive.isMobile(context)
              ? Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(
                        Icons.calendar_today,
                        color: Colors.white54,
                        size: 14,
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          duration,
                          style: TextStyle(
                            color: Colors.white70,
                            fontSize: Responsive.fontSize(context, 13),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xFF2196F3).withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      period,
                      style: TextStyle(
                        color: const Color(0xFF64B5F6),
                        fontSize: Responsive.fontSize(context, 12),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              )
              : Row(
                children: [
                  const Icon(
                    Icons.calendar_today,
                    color: Colors.white54,
                    size: 14,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    duration,
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: Responsive.fontSize(context, 13),
                    ),
                  ),
                  const SizedBox(width: 15),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xFF2196F3).withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      period,
                      style: TextStyle(
                        color: const Color(0xFF64B5F6),
                        fontSize: Responsive.fontSize(context, 12),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),

          SizedBox(height: Responsive.isMobile(context) ? 12 : 16),

          // Responsibilities section
          Text(
            'Responsibilities:',
            style: TextStyle(
              color: Colors.white,
              fontSize: Responsive.fontSize(context, 15),
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: Responsive.isMobile(context) ? 8 : 12),

          // Responsibility items
          ...responsibilities
              .map(
                (r) => Padding(
                  padding: EdgeInsets.only(
                    bottom: Responsive.isMobile(context) ? 6 : 10,
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '•  ',
                        style: TextStyle(
                          color: const Color(0xFF2196F3),
                          fontSize: Responsive.fontSize(context, 16),
                        ),
                      ),
                      Expanded(
                        child: Text(
                          r,
                          style: TextStyle(
                            color: Colors.white70,
                            fontSize: Responsive.fontSize(context, 14),
                            height: 1.5,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              )
              .toList(),
        ],
      ),
    );
  }
}
