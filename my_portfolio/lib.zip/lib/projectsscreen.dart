import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'dart:ui';
import 'dart:math' as math;

class ProjectsScreen extends StatefulWidget {
  const ProjectsScreen({super.key});

  @override
  State<ProjectsScreen> createState() => _ProjectsScreenState();
}

class _ProjectsScreenState extends State<ProjectsScreen>
    with TickerProviderStateMixin {
  late AnimationController _backgroundController;
  String _selectedFilter = 'All';

  // Enhanced Project Data
  final List<Map<String, dynamic>> projects = [
    {
      'title': 'Flex Play',
      'description':
          'Real-time turf booking with slot management and Razorpay integration.',
      'tech': ['Flutter', 'Firebase', 'Razorpay'],
      'category': 'Mobile',
      'icon': Icons.sports_cricket,
      'color': const Color(0xFF6366F1),
      'status': 'Live',
    },
    {
      'title': 'Task Manager API',
      'description':
          'Secure RESTful backend with JWT Auth and Clean Architecture.',
      'tech': ['Spring Boot', 'MySQL', 'JWT'],
      'category': 'Backend',
      'icon': Icons.api,
      'color': const Color(0xFF10B981),
      'status': 'Live',
    },
    {
      'title': 'FureverFriends',
      'description':
          'End-to-end pet rescue system connecting donors and shelters.',
      'tech': ['Flutter', 'Spring Boot', 'MySQL'],
      'category': 'Full Stack',
      'icon': Icons.pets,
      'color': const Color(0xFFF59E0B),
      'status': 'Live',
    },
    {
      'title': 'Music Streaming',
      'description':
          'High-performance audio streaming with background playback.',
      'tech': ['Flutter', 'Firebase'],
      'category': 'Mobile',
      'icon': Icons.music_note,
      'color': const Color(0xFFEC4899),
      'status': 'Completed',
    },
  ];

  @override
  void initState() {
    super.initState();
    _backgroundController = AnimationController(
      duration: const Duration(seconds: 20),
      vsync: this,
    )..repeat();
  }

  @override
  void dispose() {
    _backgroundController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final isMobile = size.width <= 600;

    return Scaffold(
      backgroundColor: const Color(0xFF030712),
      extendBodyBehindAppBar: true,
      appBar: _buildAppBar(),
      body: Stack(
        children: [
          _buildAnimatedBackground(size),
          SafeArea(
            child: CustomScrollView(
              physics: const BouncingScrollPhysics(),
              slivers: [
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 24,
                      vertical: 20,
                    ),
                    child: _buildHeroSection(isMobile),
                  ),
                ),
                SliverToBoxAdapter(child: _buildFilterBar()),
                SliverPadding(
                  padding: const EdgeInsets.all(24),
                  sliver: _buildProjectsGrid(isMobile),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAnimatedBackground(Size size) {
    return AnimatedBuilder(
      animation: _backgroundController,
      builder: (context, child) {
        return Stack(
          children: List.generate(3, (index) {
            final move = _backgroundController.value * 2 * math.pi;
            return Positioned(
              top: size.height * (0.2 * index) + (math.sin(move + index) * 50),
              left: size.width * (0.3 * index) + (math.cos(move + index) * 50),
              child: Container(
                width: 300,
                height: 300,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      const Color(0xFF6366F1).withOpacity(0.08),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            );
          }),
        );
      },
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      centerTitle: true,
      title: Text(
        "PORTFOLIO",
        style: TextStyle(
          fontWeight: FontWeight.w900,
          letterSpacing: 5,
          fontSize: 14,
          color: Colors.white.withOpacity(0.9),
        ),
      ),
      leading: const BackButton(color: Colors.white),
    );
  }

  Widget _buildHeroSection(bool isMobile) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          "Featured Work",
          style: TextStyle(
            color: Colors.white,
            fontSize: isMobile ? 32 : 48,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          "A collection of scalable mobile and backend solutions built with care.",
          style: TextStyle(color: Colors.white54, fontSize: 16),
        ),
      ],
    ).animate().fadeIn(duration: 600.ms).slideX(begin: -0.1);
  }

  Widget _buildFilterBar() {
    final filters = ['All', 'Mobile', 'Backend', 'Full Stack'];
    return SizedBox(
      height: 50,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 24),
        itemCount: filters.length,
        itemBuilder: (context, index) {
          final isSelected = _selectedFilter == filters[index];
          return GestureDetector(
            onTap: () => setState(() => _selectedFilter = filters[index]),
            child: AnimatedContainer(
              duration: 300.ms,
              margin: const EdgeInsets.only(right: 12),
              padding: const EdgeInsets.symmetric(horizontal: 20),
              decoration: BoxDecoration(
                color:
                    isSelected
                        ? const Color(0xFF6366F1)
                        : Colors.white.withOpacity(0.05),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isSelected ? Colors.transparent : Colors.white10,
                ),
              ),
              alignment: Alignment.center,
              child: Text(
                filters[index],
                style: TextStyle(
                  color: isSelected ? Colors.white : Colors.white60,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildProjectsGrid(bool isMobile) {
    final filtered =
        _selectedFilter == 'All'
            ? projects
            : projects.where((p) => p['category'] == _selectedFilter).toList();

    return SliverGrid(
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: isMobile ? 1 : 2,
        mainAxisSpacing: 24,
        crossAxisSpacing: 24,
        mainAxisExtent: 260,
      ),
      delegate: SliverChildBuilderDelegate(
        (context, index) => _buildProjectCard(filtered[index], index),
        childCount: filtered.length,
      ),
    );
  }

  Widget _buildProjectCard(Map<String, dynamic> project, int index) {
    final color = project['color'] as Color;
    return Container(
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.03),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: Colors.white.withOpacity(0.05)),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: color.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(project['icon'], color: color, size: 24),
                        ),
                        _buildStatusBadge(project['status'], color),
                      ],
                    ),
                    const Spacer(),
                    Text(
                      project['title'],
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      project['description'],
                      style: const TextStyle(
                        color: Colors.white54,
                        fontSize: 13,
                        height: 1.4,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 16),
                    _buildTechRow(project['tech'], color),
                  ],
                ),
              ),
            ),
          ),
        )
        .animate()
        .fadeIn(delay: (index * 100).ms)
        .slideY(begin: 0.2, curve: Curves.easeOutCubic);
  }

  Widget _buildStatusBadge(String status, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Text(
        status,
        style: TextStyle(
          color: color,
          fontSize: 10,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildTechRow(List<String> tech, Color color) {
    return Wrap(
      spacing: 8,
      children:
          tech
              .map(
                (t) => Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 4,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.05),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    t,
                    style: const TextStyle(color: Colors.white38, fontSize: 10),
                  ),
                ),
              )
              .toList(),
    );
  }
}
