import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'dart:ui';
import 'dart:math' as math;

class SkillsScreen extends StatefulWidget {
  const SkillsScreen({super.key});

  @override
  State<SkillsScreen> createState() => _SkillsScreenState();
}

class _SkillsScreenState extends State<SkillsScreen>
    with TickerProviderStateMixin {
  late AnimationController _rotationController;
  String _selectedCategory = 'All';

  final Map<String, List<Map<String, dynamic>>> skillsData = {
    'Mobile': [
      {
        'name': 'Flutter',
        'level': 0.9,
        'icon': Icons.phone_android,
        'color': const Color(0xFF02569B),
        'years': 3,
      },
      {
        'name': 'Dart',
        'level': 0.85,
        'icon': Icons.code,
        'color': const Color(0xFF0175C2),
        'years': 3,
      },
      {
        'name': 'Firebase',
        'level': 0.8,
        'icon': Icons.cloud,
        'color': const Color(0xFFFFCA28),
        'years': 2,
      },
      {
        'name': 'REST APIs',
        'level': 0.88,
        'icon': Icons.api,
        'color': const Color(0xFF10B981),
        'years': 3,
      },
    ],
    'Backend': [
      {
        'name': 'Java',
        'level': 0.85,
        'icon': Icons.coffee,
        'color': const Color(0xFFF89820),
        'years': 4,
      },
      {
        'name': 'Spring Boot',
        'level': 0.75,
        'icon': Icons.bolt,
        'color': const Color(0xFF6DB33F),
        'years': 2,
      },
      {
        'name': 'MySQL',
        'level': 0.8,
        'icon': Icons.storage,
        'color': const Color(0xFF00758F),
        'years': 3,
      },
      {
        'name': 'Clean Arch',
        'level': 0.7,
        'icon': Icons.architecture,
        'color': const Color(0xFF9C27B0),
        'years': 1,
      },
    ],
    'Tools': [
      {
        'name': 'Git',
        'level': 0.85,
        'icon': Icons.merge_type,
        'color': const Color(0xFFF05032),
        'years': 4,
      },
      {
        'name': 'Docker',
        'level': 0.7,
        'icon': Icons.terminal,
        'color': const Color(0xFF2496ED),
        'years': 2,
      },
      {
        'name': 'Postman',
        'level': 0.8,
        'icon': Icons.send,
        'color': const Color(0xFFFF6C37),
        'years': 3,
      },
    ],
  };

  @override
  void initState() {
    super.initState();
    _rotationController = AnimationController(
      duration: const Duration(seconds: 30),
      vsync: this,
    )..repeat();
  }

  @override
  void dispose() {
    _rotationController.dispose();
    super.dispose();
  }

  List<Map<String, dynamic>> get filteredSkills {
    if (_selectedCategory == 'All') {
      return skillsData.values.expand((e) => e).toList();
    }
    return skillsData[_selectedCategory] ?? [];
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final bool isMobile = size.width < 600;

    return Scaffold(
      backgroundColor: const Color(0xFF0F172A),
      extendBodyBehindAppBar: true,
      appBar: _buildAppBar(isMobile),
      body: Stack(
        children: [
          _buildAnimatedBackground(size),
          SafeArea(
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(
                horizontal: isMobile ? 20 : 40,
                vertical: 20,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildSectionHeader(
                    "Technical Arsenal",
                    "Engineering scalable solutions with modern tech.",
                  ),
                  const SizedBox(height: 30),
                  _buildFilterChips(),
                  const SizedBox(height: 30),
                  _buildResponsiveGrid(isMobile),
                  const SizedBox(height: 50),
                  _buildSummaryStats(isMobile),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAnimatedBackground(Size size) {
    return AnimatedBuilder(
      animation: _rotationController,
      builder: (context, child) {
        return Stack(
          children: List.generate(5, (index) {
            double angle =
                (_rotationController.value * 2 * math.pi) + (index * 1.5);
            return Positioned(
              left: size.width / 2 + math.cos(angle) * (150 * index / 2) - 100,
              top: size.height / 2 + math.sin(angle) * (150 * index / 2) - 100,
              child: Container(
                width: 250,
                height: 250,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      const Color(0xFF3B82F6).withOpacity(0.05),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            );
          }),
        );
      },
    );
  }

  PreferredSizeWidget _buildAppBar(bool isMobile) {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      centerTitle: true,
      leading: IconButton(
        icon: const Icon(
          Icons.arrow_back_ios_new,
          color: Colors.white,
          size: 20,
        ),
        onPressed: () => Navigator.pop(context),
      ),
      title: Text(
        "SKILLS",
        style: TextStyle(
          color: Colors.white,
          fontSize: 16,
          fontWeight: FontWeight.w800,
          letterSpacing: 4,
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title, String subtitle) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontSize: 32,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          subtitle,
          style: TextStyle(fontSize: 16, color: Colors.white.withOpacity(0.5)),
        ),
      ],
    ).animate().fadeIn(duration: 800.ms).slideX(begin: -0.1);
  }

  Widget _buildFilterChips() {
    final categories = ['All', 'Mobile', 'Backend', 'Tools'];
    return Wrap(
      spacing: 12,
      children:
          categories.map((cat) {
            bool isSelected = _selectedCategory == cat;
            return GestureDetector(
              onTap: () => setState(() => _selectedCategory = cat),
              child: AnimatedContainer(
                duration: 300.ms,
                padding: const EdgeInsets.symmetric(
                  horizontal: 24,
                  vertical: 12,
                ),
                decoration: BoxDecoration(
                  color:
                      isSelected
                          ? const Color(0xFF3B82F6)
                          : Colors.white.withOpacity(0.05),
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(
                    color: isSelected ? Colors.transparent : Colors.white12,
                  ),
                ),
                child: Text(
                  cat,
                  style: TextStyle(
                    color: isSelected ? Colors.white : Colors.white60,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            );
          }).toList(),
    );
  }

  Widget _buildResponsiveGrid(bool isMobile) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: isMobile ? 1 : 3,
        crossAxisSpacing: 20,
        mainAxisSpacing: 20,
        mainAxisExtent: 180,
      ),
      itemCount: filteredSkills.length,
      itemBuilder: (context, index) {
        final skill = filteredSkills[index];
        return _buildGlassSkillCard(skill, index);
      },
    );
  }

  Widget _buildGlassSkillCard(Map<String, dynamic> skill, int index) {
    Color color = skill['color'];
    return Container(
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.03),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: Colors.white.withOpacity(0.08)),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: color.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(skill['icon'], color: color, size: 24),
                        ),
                        Text(
                          "${skill['years']} YRS",
                          style: TextStyle(
                            color: color,
                            fontWeight: FontWeight.bold,
                            fontSize: 10,
                          ),
                        ),
                      ],
                    ),
                    const Spacer(),
                    Text(
                      skill['name'],
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 12),
                    _buildProgressBar(skill['level'], color),
                  ],
                ),
              ),
            ),
          ),
        )
        .animate()
        .fadeIn(delay: (index * 100).ms)
        .scale(begin: const Offset(0.9, 0.9));
  }

  Widget _buildProgressBar(double level, Color color) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              "Proficiency",
              style: TextStyle(color: Colors.white38, fontSize: 10),
            ),
            Text(
              "${(level * 100).toInt()}%",
              style: TextStyle(
                color: color,
                fontSize: 10,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        const SizedBox(height: 6),
        Stack(
          children: [
            Container(
              height: 4,
              decoration: BoxDecoration(
                color: Colors.white10,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            AnimatedContainer(
              duration: 1500.ms,
              curve: Curves.easeOutCubic,
              height: 4,
              width: 400 * level, // Approximate for grid width
              decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(2),
                boxShadow: [
                  BoxShadow(color: color.withOpacity(0.5), blurRadius: 8),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildSummaryStats(bool isMobile) {
    return Container(
      padding: const EdgeInsets.all(30),
      decoration: BoxDecoration(
        color: const Color(0xFF3B82F6).withOpacity(0.05),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: const Color(0xFF3B82F6).withOpacity(0.2)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildStatItem("${filteredSkills.length}", "Total Techs"),
          const VerticalDivider(color: Colors.white12),
          _buildStatItem("5+", "Live Projects"),
          const VerticalDivider(color: Colors.white12),
          _buildStatItem("3yr", "Avg Exp"),
        ],
      ),
    ).animate().slideY(begin: 0.2);
  }

  Widget _buildStatItem(String val, String label) {
    return Column(
      children: [
        Text(
          val,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(
          label,
          style: const TextStyle(color: Colors.white38, fontSize: 12),
        ),
      ],
    );
  }
}
